import React from 'react';
import ReactDOM from 'react-dom';
import Main from './app/main.js';


ReactDOM.render(
    <Main skuSearch="" />,
    document.getElementById('skusearch-main')
);